let canvas, ctx, ws;
let myId = null;
let worldSize = 4500;
let selectedSkin = 'CAMARADA';
let inGame = false;
let isPaused = false;

let gameState = { players: [], foods: [], powerups: [], leaderboard: [] };
let camera = { x: 0, y: 0 };
let mouseAngle = 0;
let isBoosting = false;

let cdDashEnd = 0;
let cdMagnetEnd = 0;

// MOTOR DE EFECTOS DE SONIDO WEB AUDIO API
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function initAudio() {
    if (!audioCtx) audioCtx = new AudioContext();
}

function playEatSound() {
    if (!audioCtx) return;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(400, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.08);
}

function playPowerupSound() {
    if (!audioCtx) return;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(300, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.25);
    gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.25);
}

function init() {
    canvas = document.getElementById('gameCanvas');
    ctx = canvas.getContext('2d');
    resize();

    window.addEventListener('resize', resize);

    document.querySelectorAll('.skin-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.skin-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedSkin = btn.dataset.skin;
        });
    });

    document.getElementById('play-btn').addEventListener('click', () => {
        initAudio();
        joinGame();
    });

    document.getElementById('resume-btn').addEventListener('click', togglePause);
    document.getElementById('quit-btn').addEventListener('click', quitToMenu);

    window.addEventListener('mousemove', e => {
        const cx = window.innerWidth / 2;
        const cy = window.innerHeight / 2;
        mouseAngle = Math.atan2(e.clientY - cy, e.clientX - cx);
    });

    window.addEventListener('mousedown', () => { if (inGame && !isPaused) isBoosting = true; });
    window.addEventListener('mouseup', () => { isBoosting = false; });

    window.addEventListener('keydown', e => {
        if (e.code === 'Escape' && inGame) {
            togglePause();
        }
        if (inGame && !isPaused) {
            if (e.code === 'Space') triggerSkill('DASH');
            if (e.code === 'KeyE') triggerSkill('MAGNET');
        }
    });

    requestAnimationFrame(renderLoop);
}

function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

function joinGame() {
    const name = document.getElementById('nickname').value || 'Camarada';
    document.getElementById('login-overlay').classList.add('hidden');
    document.getElementById('pause-overlay').classList.add('hidden');
    document.getElementById('hud').classList.remove('hidden');

    inGame = true;
    isPaused = false;

    if (!ws || ws.readyState !== WebSocket.OPEN) {
        const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
        ws = new WebSocket(`${protocol}//${location.host}`);

        ws.onmessage = (e) => {
            const msg = JSON.parse(e.data);
            if (msg.type === 'INIT') {
                myId = msg.id;
                worldSize = msg.worldSize;
            }
            if (msg.type === 'STATE') {
                const prevFoodCount = gameState.foods ? gameState.foods.length : 0;
                gameState = msg;
                if (gameState.foods.length < prevFoodCount) playEatSound();
                updateHUD();
            }
        };

        ws.onopen = () => {
            ws.send(JSON.stringify({ type: 'JOIN', name, skin: selectedSkin }));
        };
    } else {
        ws.send(JSON.stringify({ type: 'JOIN', name, skin: selectedSkin }));
    }

    // Intervalo de entrada
    if (!window.inputInterval) {
        window.inputInterval = setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN && inGame && !isPaused) {
                ws.send(JSON.stringify({
                    type: 'INPUT',
                    angle: mouseAngle,
                    boosting: isBoosting
                }));
            }
        }, 33);
    }
}

function togglePause() {
    isPaused = !isPaused;
    const pauseEl = document.getElementById('pause-overlay');
    if (isPaused) {
        pauseEl.classList.remove('hidden');
        isBoosting = false;
    } else {
        pauseEl.classList.add('hidden');
    }
}

function quitToMenu() {
    inGame = false;
    isPaused = false;
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'LEAVE_MATCH' }));
    }
    document.getElementById('pause-overlay').classList.add('hidden');
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('login-overlay').classList.remove('hidden');
}

function triggerSkill(skill) {
    const now = Date.now();
    if (skill === 'DASH' && now > cdDashEnd) {
        cdDashEnd = now + 4000;
        ws.send(JSON.stringify({ type: 'SKILL', skill: 'DASH' }));
    }
    if (skill === 'MAGNET' && now > cdMagnetEnd) {
        cdMagnetEnd = now + 8000;
        ws.send(JSON.stringify({ type: 'SKILL', skill: 'MAGNET' }));
    }
}

function updateHUD() {
    const lbEl = document.getElementById('lb-list');
    lbEl.innerHTML = '';
    gameState.leaderboard.forEach(p => {
        const li = document.createElement('li');
        li.innerHTML = `<span>${p.name}</span><strong>${p.score}</strong>`;
        lbEl.appendChild(li);
    });

    const me = gameState.players.find(p => p.id === myId);
    if (me) {
        document.getElementById('score-val').innerText = me.score;
        camera.x += (me.x - camera.x) * 0.1;
        camera.y += (me.y - camera.y) * 0.1;

        // Buffs Activos
        const buffsEl = document.getElementById('buffs-bar');
        buffsEl.innerHTML = '';
        if (me.shieldActive) buffsEl.innerHTML += '<div class="buff-tag">ESCUDO</div>';
        if (me.doubleMassActive) buffsEl.innerHTML += '<div class="buff-tag">DOBLE MASA</div>';
        if (me.speedBoostActive) buffsEl.innerHTML += '<div class="buff-tag">VELOCIDAD</div>';
    }

    const now = Date.now();
    document.getElementById('cd-dash').style.height = Math.max(0, (cdDashEnd - now) / 4000) * 100 + '%';
    document.getElementById('cd-magnet').style.height = Math.max(0, (cdMagnetEnd - now) / 8000) * 100 + '%';

    drawMinimap();
}

function drawMinimap() {
    const mm = document.getElementById('minimap');
    const mctx = mm.getContext('2d');
    mctx.clearRect(0, 0, 150, 150);

    const scale = 150 / worldSize;

    // Fondo radar
    mctx.fillStyle = 'rgba(0, 240, 255, 0.05)';
    mctx.fillRect(0, 0, 150, 150);

    // Power-ups en minimapa
    mctx.fillStyle = '#ffff00';
    gameState.powerups.forEach(pu => {
        const mx = (pu.x + worldSize / 2) * scale;
        const my = (pu.y + worldSize / 2) * scale;
        mctx.fillRect(mx - 1, my - 1, 3, 3);
    });

    // Jugadores
    gameState.players.forEach(p => {
        const mx = (p.x + worldSize / 2) * scale;
        const my = (p.y + worldSize / 2) * scale;
        mctx.fillStyle = p.id === myId ? '#00f0ff' : '#ff0055';
        mctx.beginPath();
        mctx.arc(mx, my, p.id === myId ? 3.5 : 2, 0, Math.PI * 2);
        mctx.fill();
    });
}

function renderLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (inGame) {
        ctx.save();
        ctx.translate(canvas.width / 2 - camera.x, canvas.height / 2 - camera.y);

        drawGrid();

        // Comida y Orbes de Muerte
        gameState.foods.forEach(f => {
            if (f.isDeathOrb) {
                // Grandes orbes luminosos
                ctx.shadowBlur = 15;
                ctx.shadowColor = '#ff0055';
                ctx.fillStyle = '#ff3377';
                ctx.beginPath();
                ctx.arc(f.x, f.y, f.size, 0, Math.PI * 2);
                ctx.fill();
                ctx.shadowBlur = 0;
            } else {
                ctx.fillStyle = `hsl(${f.color}, 100%, 60%)`;
                ctx.beginPath();
                ctx.arc(f.x, f.y, f.size, 0, Math.PI * 2);
                ctx.fill();
            }
        });

        // Power-ups
        gameState.powerups.forEach(pu => {
            ctx.shadowBlur = 12;
            ctx.shadowColor = '#ffff00';
            ctx.fillStyle = '#ffff00';
            ctx.beginPath();
            ctx.arc(pu.x, pu.y, 10, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
            ctx.fillStyle = '#000';
            ctx.font = 'bold 8px Segoe UI';
            ctx.textAlign = 'center';
            ctx.fillText(pu.type[0], pu.x, pu.y + 3);
        });

        // Serpientes
        gameState.players.forEach(p => drawSnake(p));

        ctx.restore();
    }

    requestAnimationFrame(renderLoop);
}

function drawGrid() {
    const half = worldSize / 2;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;

    for (let x = -half; x <= half; x += 120) {
        ctx.beginPath(); ctx.moveTo(x, -half); ctx.lineTo(x, half); ctx.stroke();
    }
    for (let y = -half; y <= half; y += 120) {
        ctx.beginPath(); ctx.moveTo(-half, y); ctx.lineTo(half, y); ctx.stroke();
    }

    ctx.strokeStyle = '#ff0055';
    ctx.lineWidth = 8;
    ctx.strokeRect(-half, -half, worldSize, worldSize);
}

function drawSnake(p) {
    if (!p.body || p.body.length === 0) return;

    let primaryColor = '#00f0ff';
    let secondaryColor = '#0055ff';

    if (p.skin === 'CAMARADA') { primaryColor = '#ff0000'; secondaryColor = '#ffcc00'; }
    if (p.skin === 'CAPITALISTA') { primaryColor = '#ffd700'; secondaryColor = '#ffffff'; }
    if (p.skin === 'DICTADOR') { primaryColor = '#4b5320'; secondaryColor = '#111111'; }
    if (p.skin === 'BANQUERO') { primaryColor = '#111111'; secondaryColor = '#333333'; }
    if (p.skin === 'POLITICO') { primaryColor = '#ff8c00'; secondaryColor = '#00008b'; }
    if (p.skin === 'TOXICO') { primaryColor = '#39ff14'; secondaryColor = '#006600'; }
    if (p.skin === 'NEON_CYBER') { primaryColor = '#ff00ff'; secondaryColor = '#00f0ff'; }
    if (p.skin === 'MATRIX') { primaryColor = '#00ff00'; secondaryColor = '#002b00'; }

    // Renderizar cuerpo
    for (let i = p.body.length - 1; i >= 0; i--) {
        const seg = p.body[i];
        const radius = Math.max(8, 14 - (i * 0.04));

        ctx.fillStyle = (i % 2 === 0) ? primaryColor : secondaryColor;
        ctx.beginPath();
        ctx.arc(seg.x, seg.y, radius, 0, Math.PI * 2);
        ctx.fill();

        // Escudo visual
        if (p.shieldActive && i === 0) {
            ctx.strokeStyle = '#00f0ff';
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(seg.x, seg.y, radius + 6, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    // Cabeza
    const head = p.body[0];
    ctx.save();
    ctx.translate(head.x, head.y);
    ctx.rotate(p.angle);

    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(6, -6, 4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(6, 6, 4, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.arc(7, -6, 2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(7, 6, 2, 0, Math.PI * 2); ctx.fill();

    ctx.restore();

    // Apodo
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 12px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText(p.name, head.x, head.y - 22);
}

window.onload = init;
